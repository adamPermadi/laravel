<div class ="conteiner">
    <div class="row mt-3">
        <div class ="col-md-6">
            <h3>Daftar Mahasiswa</h3>
            <ul class="list-group">
                <li class="list-group-item">Cras jusdo odio</li>
            </ul>
        </div>
    </div>
</div>